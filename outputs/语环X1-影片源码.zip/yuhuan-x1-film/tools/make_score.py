#!/usr/bin/env python3
"""Original procedural score for Yuhuan X1. No samples or third-party music."""
import argparse
from pathlib import Path
import wave
import numpy as np

RATE=48000
DURATION=54
rng=np.random.default_rng(20261018)
track=np.zeros((RATE*DURATION,2),np.float64)

def mix(start,signal,gain=1.0,pan=0.0):
    index=max(0,int(start*RATE)); signal=np.asarray(signal); length=min(len(signal),len(track)-index)
    if length<=0:return
    signal=signal[:length]*gain
    if signal.ndim==1:
        track[index:index+length,0]+=signal*np.cos((pan+1)*np.pi/4)
        track[index:index+length,1]+=signal*np.sin((pan+1)*np.pi/4)
    else:track[index:index+length]+=signal

def envelope(t,d,attack=1.5,release=2.5):
    return np.minimum(1,t/attack)**2 * np.minimum(1,np.maximum(0,d-t)/release)**2

# Slow D-minor / B-flat / F / C voicings, soft detuning and long tails.
chords=[(0,9,[146.8324,174.6141,220,261.6256,329.6276]),
        (7,9,[116.5409,146.8324,174.6141,220,261.6256]),
        (14,11,[130.8128,174.6141,220,261.6256,391.9954]),
        (23,10,[130.8128,164.8138,195.9977,261.6256,293.6648]),
        (31,10,[146.8324,174.6141,220,261.6256,329.6276]),
        (39,9,[116.5409,146.8324,174.6141,220,349.2282]),
        (46,8,[130.8128,174.6141,220,261.6256,349.2282])]
for start,d,notes in chords:
    t=np.arange(int(d*RATE))/RATE
    env=envelope(t,d,1.8,2.8)
    for i,f in enumerate(notes):
        phase=rng.uniform(0,2*np.pi)
        left=np.sin(2*np.pi*f*t+phase)+.20*np.sin(2*np.pi*2*f*t+.3)+.06*np.sin(2*np.pi*3*f*t)
        right=np.sin(2*np.pi*(f+.12)*t+phase)+.20*np.sin(2*np.pi*(2*f+.08)*t+.3)+.06*np.sin(2*np.pi*(3*f+.1)*t)
        breathing=.8+.2*np.sin(t*.7+i)
        mix(start,np.column_stack([left,right])*env[:,None]*breathing[:,None],.021)
    bass=np.sin(2*np.pi*(notes[0]/2)*t)+.20*np.sin(2*np.pi*notes[0]*t)
    mix(start,bass*env,.055)

# Spacious, sparse upper harmonics; delays are synthesized, not sampled.
for start,f in [(2.5,880),(10.5,698.456),(15.3,1046.5),(19.8,880),(24.8,783.99),(32.8,880),(35.2,1046.5),(40.6,1174.66),(43.2,1046.5),(47.8,880),(50.6,1396.91)]:
    d=3.4;t=np.arange(int(d*RATE))/RATE
    s=(np.sin(2*np.pi*f*t)+.3*np.sin(2*np.pi*f*2.001*t)+.08*np.sin(2*np.pi*f*3.002*t))*np.exp(-t*1.5)*np.minimum(1,t/.018)
    for delay,gain,pan in [(0,.022,-.3),(.27,.012,.4),(.61,.006,-.7)]:mix(start+delay,s,gain,pan)

# Filtered air and low cinematic transitions.
for start in [0.7,6.5,13.5,22.5,30.5,38.5,45.5]:
    d=1.6;t=np.arange(int(d*RATE))/RATE
    noise=rng.normal(0,1,len(t));freq=np.fft.rfftfreq(len(t),1/RATE)
    spectrum=np.fft.rfft(noise);filt=np.exp(-((freq-1800)/1800)**2)*(1-np.exp(-(freq/180)**2))
    air=np.fft.irfft(spectrum*filt,n=len(t));air=air/(np.std(air)+1e-8)
    env=np.sin(np.pi*t/d)**3
    mix(start,air*env,.019,-.25);mix(start+.035,air[::-1]*env,.017,.25)
    impact=np.sin(2*np.pi*(45*t+30*(1-np.exp(-t*9))/9))*np.exp(-t*4)*np.minimum(1,t/.02)
    mix(start+.42,impact,.10)

# Three light tactile button clicks, tuned to the protection sequence.
for start in [25.45,27.75,28.25]:
    d=.16;t=np.arange(int(d*RATE))/RATE
    click=(np.sin(2*np.pi*1900*t)*np.exp(-t*95)+.15*rng.normal(0,1,len(t))*np.exp(-t*130))*np.minimum(1,t/.001)
    mix(start,click,.07,.1)

# Quiet sub-pulses establish motion without advertising-style percussion.
for start in np.arange(14.2,46,1.7142857):
    d=.7;t=np.arange(int(d*RATE))/RATE
    p=np.sin(2*np.pi*55*t)*np.exp(-t*8)*np.minimum(1,t/.025)
    mix(float(start),p,.025)

# Global fades and a subtle stereo tail.
time=np.arange(len(track))/RATE
track*=np.minimum(1,time/2)[:,None]*np.minimum(1,np.maximum(0,DURATION-time)/2.7)[:,None]
track=np.tanh(track*1.1)
track*=.88/(np.max(np.abs(track))+1e-9)
parser=argparse.ArgumentParser();parser.add_argument('output',type=Path);args=parser.parse_args()
args.output.parent.mkdir(parents=True,exist_ok=True)
with wave.open(str(args.output),'wb') as f:
    f.setnchannels(2);f.setsampwidth(2);f.setframerate(RATE);f.writeframes((track*32767).astype('<i2').tobytes())
print(f'Original stereo score: {DURATION}s / {RATE}Hz -> {args.output}')
