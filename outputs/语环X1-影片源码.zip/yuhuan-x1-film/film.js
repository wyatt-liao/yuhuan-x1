import * as THREE from './vendor/three.module.min.js';

/** A deterministic, procedural film. No stock footage, remote fonts or network assets. */
export const DURATION = 54;
export const CHAPTERS = [0, 7, 14, 23, 31, 39, 46];
const W = 1920, H = 1080, TOP = 132, BOTTOM = 948;
const canvas = document.querySelector('#film');
const ctx = canvas.getContext('2d', { alpha: false });
const q = new URLSearchParams(location.search);
const capture = q.has('capture');
const sans = '"Helvetica Neue", "PingFang SC", -apple-system, sans-serif';
const mono = '"SFMono-Regular", "Menlo", monospace';
const WHITE = '#e9edf2', MUTED = '#939da9', BLUE = '#a3c8eb';
const clamp = (x, lo=0, hi=1) => Math.max(lo, Math.min(hi,x));
const lerp = (a,b,t) => a+(b-a)*t;
const smooth = t => {t=clamp(t);return t*t*(3-2*t);};
const out = t => 1-Math.pow(1-clamp(t),4);
const expo = t => t<=0?0:1-Math.pow(2,-8*t);
// Damped anticipation-free entrance: a small, controlled elastic overshoot.
const elastic = t => { t=clamp(t); return 1-Math.exp(-7*t)*(Math.cos(8*t)+.32*Math.sin(8*t)); };
const win = (t,a,b,fade=.65) => smooth((t-a)/fade)*smooth((b-t)/fade);
function easeBezier(x,x1=.23,y1=1,x2=.32,y2=1){
  x=clamp(x); let lo=0, hi=1, u=x;
  for(let i=0;i<12;i++){let v=3*(1-u)*(1-u)*u*x1+3*(1-u)*u*u*x2+u*u*u;if(v<x)lo=u;else hi=u;u=(lo+hi)/2;}
  return 3*(1-u)*(1-u)*u*y1+3*(1-u)*u*u*y2+u*u*u;
}

const renderer = new THREE.WebGLRenderer({antialias:true, alpha:true, preserveDrawingBuffer:true, powerPreference:'high-performance'});
renderer.setSize(W,H); renderer.setPixelRatio(1);
renderer.setClearColor(0x000000,0);
renderer.outputColorSpace=THREE.SRGBColorSpace;
renderer.toneMapping=THREE.ACESFilmicToneMapping;
renderer.toneMappingExposure=1.0;
const scene = new THREE.Scene();
const camera = new THREE.PerspectiveCamera(33,W/H,.1,200);
const ortho = new THREE.OrthographicCamera(-13.4,13.4,7.54,-7.54,.1,200);
const ambient = new THREE.HemisphereLight(0xc7d8ee,0x13141a,1.2);scene.add(ambient);
function light(color,power,pos){const l=new THREE.DirectionalLight(color,power);l.position.set(...pos);scene.add(l);return l;}
const key = light(0xe6edff,5,[-6,8,10]);
const rim = light(0x8caed9,4,[8,0,-3]);
const strip = light(0xffffff,3,[-8,-3,4]);
const warm = light(0xf8eddf,.7,[1,7,5]);

// Procedural studio reflection environment: large softboxes plus narrow strip lights.
function studioEnvironment(){
  const c=document.createElement('canvas'); c.width=1024;c.height=512;const x=c.getContext('2d');
  x.fillStyle='#080b12';x.fillRect(0,0,1024,512);
  const areas=[[210,180,270,92,'#e5ebf4'],[720,245,140,180,'#a6bfdd'],[430,380,310,13,'#eef5ff'],[40,270,35,190,'#7a8eaa']];
  for(const [px,py,w,h,color]of areas){x.fillStyle=color;x.filter='blur(12px)';x.fillRect(px-w/2,py-h/2,w,h);x.filter='none';}
  const map=new THREE.CanvasTexture(c);map.mapping=THREE.EquirectangularReflectionMapping;map.colorSpace=THREE.SRGBColorSpace;
  const pmrem=new THREE.PMREMGenerator(renderer);const env=pmrem.fromEquirectangular(map).texture;scene.environment=env;map.dispose();pmrem.dispose();
}
studioEnvironment();

function roundedShape(w,h,r){
 const s=new THREE.Shape(),x=-w/2,y=-h/2;
 s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);
 s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
 s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s;
}
function bodyGeometry(w,h,r,d,b=.06){const g=new THREE.ExtrudeGeometry(roundedShape(w,h,r),{depth:d,bevelEnabled:b>0,bevelSegments:4,steps:1,bevelSize:b,bevelThickness:b,curveSegments:20});g.translate(0,0,-d/2);g.computeVertexNormals();return g;}
function mesh(geo,mat,parent,pos=[0,0,0]){const m=new THREE.Mesh(geo,mat);m.position.set(...pos);parent.add(m);return m;}
function face(w,h,r,mat,parent,z){const g=new THREE.ShapeGeometry(roundedShape(w,h,r),32);const uv=g.attributes.uv;for(let i=0;i<uv.count;i++){uv.setXY(i,uv.getX(i)/w+.5,uv.getY(i)/h+.5);}uv.needsUpdate=true;return mesh(g,mat,parent,[0,0,z]);}
function outline(w,h,r,z,color,opacity=1){
 const pts=roundedShape(w,h,r).getPoints(144).map(p=>new THREE.Vector3(p.x,p.y,z));
 const g=new THREE.BufferGeometry().setFromPoints(pts);return new THREE.LineLoop(g,new THREE.LineBasicMaterial({color,transparent:true,opacity}));
}
function seeded(seed){let x=seed;return ()=>{x=(Math.imul(x,1664525)+1013904223)|0;return(x>>>0)/4294967296;};}
function brushedTexture(){
 const c=document.createElement('canvas');c.width=1024;c.height=1024;let x=c.getContext('2d');const rng=seeded(42);
 x.fillStyle='#a3a6ab';x.fillRect(0,0,1024,1024);
 for(let y=0;y<1024;y++){let a=.015+rng()*.06;x.strokeStyle=`rgba(${rng()>.5?'255,255,255':'0,0,0'},${a})`;x.lineWidth=.5;x.beginPath();x.moveTo(0,y);x.lineTo(1024,y+(rng()-.5)*.6);x.stroke();}
 const t=new THREE.CanvasTexture(c);t.wrapS=t.wrapT=THREE.RepeatWrapping;t.repeat.set(1,1);t.colorSpace=THREE.SRGBColorSpace;return t;
}
const brushed=brushedTexture();
const metal=new THREE.MeshPhysicalMaterial({color:0x6f7781,metalness:1,roughness:.24,clearcoat:.45,clearcoatRoughness:.25,envMapIntensity:1.2});
const frontmat=new THREE.MeshPhysicalMaterial({color:0x292d33,metalness:.83,roughness:.39,map:brushed,clearcoat:.24,clearcoatRoughness:.4,envMapIntensity:.7});
const black=new THREE.MeshStandardMaterial({color:0x040608,metalness:.35,roughness:.45});
const chrome=new THREE.MeshPhysicalMaterial({color:0x9da9b9,metalness:1,roughness:.18});
const card=new THREE.Group();scene.add(card);
mesh(bodyGeometry(10.6,7.9,.46,.42,.04),metal,card);
mesh(bodyGeometry(10.50,7.80,.43,.03,.018),black,card,[0,0,.254]);
face(10.44,7.74,.40,frontmat,card,.302);
face(10.44,7.74,.4,frontmat,card,-.302).rotation.y=Math.PI;
const faceRim=outline(10.49,7.79,.43,.303,0xc8d7e8,.32);card.add(faceRim);
const backRim=outline(10.49,7.79,.43,-.303,0x99adc9,.3);card.add(backRim);

// The four acoustic ports are positioned at the four corners of the concept enclosure.
const micPositions=[[-4.65,3.25],[4.65,3.25],[-4.65,-3.25],[4.65,-3.25]];
const micLeds=[];
for(const [x,y]of micPositions){
 mesh(new THREE.RingGeometry(.105,.143,40),chrome,card,[x,y,.309]);
 mesh(new THREE.CircleGeometry(.104,40),black,card,[x,y,.313]);
 for(let a=-1;a<=1;a++)for(let b=-1;b<=1;b++)if(a*a+b*b<2.1)mesh(new THREE.CircleGeometry(.012,8),new THREE.MeshBasicMaterial({color:0x353a43}),card,[x+a*.045,y+b*.045,.315]);
 const ledmat=new THREE.MeshBasicMaterial({color:0xbadfff,transparent:true,opacity:0});
 const ring=mesh(new THREE.RingGeometry(.18,.20,64),ledmat,card,[x,y,.319]);micLeds.push(ring);
}

const buttons=[];
for(let i=0;i<2;i++){
 const button=new THREE.Group();button.position.set(-3.24+i*1.15,-3.98,0);card.add(button);
 const base=mesh(bodyGeometry(.68,.20,.09,.12,.035),chrome,button);base.rotation.x=Math.PI/2;
 const insert=mesh(bodyGeometry(.56,.12,.05,.06,.015),black,button,[0,-.11,0]);insert.rotation.x=Math.PI/2;
 buttons.push(button);
}
// USB-C cut-out on the lower long edge; this is an exterior concept, not a fabrication model.
const usb=new THREE.Group();usb.position.set(1.95,-3.991,0);usb.rotation.x=Math.PI/2;card.add(usb);
mesh(bodyGeometry(.95,.22,.10,.015,.025),chrome,usb);
face(.84,.15,.068,black,usb,.034);
face(.58,.035,.015,new THREE.MeshStandardMaterial({color:0x555765,roughness:.4}),usb,.04);

function decalTexture(){
 const c=document.createElement('canvas');c.width=2048;c.height=1024;const x=c.getContext('2d');
 x.clearRect(0,0,c.width,c.height);x.fillStyle='rgba(200,208,218,.72)';
 x.font=`300 64px ${sans}`;x.textAlign='left';x.fillText('语环',150,780);x.font=`300 68px ${sans}`;x.fillText('X1',303,782);
 x.fillStyle='rgba(140,151,168,.65)';x.font=`18px ${mono}`;x.fillText('YUHUAN  /  PERSONAL MEMORY',153,831);
 // Machined, concentric memory emblem.
 x.lineWidth=4;x.strokeStyle='rgba(152,172,197,.55)';
 for(const [r,a,b]of [[63,-.9,4.4],[45,.7,5.7],[27,-1.3,3.8]]){x.beginPath();x.arc(1770,220,r,a,b);x.stroke();}
 const t=new THREE.CanvasTexture(c);t.colorSpace=THREE.SRGBColorSpace;return t;
}
const decals=new THREE.MeshBasicMaterial({map:decalTexture(),transparent:true,depthWrite:false});
mesh(new THREE.PlaneGeometry(10.42,7.72),decals,card,[0,0,.312]);
const statusMat=new THREE.MeshBasicMaterial({color:0xb6e0fc});
mesh(new THREE.CircleGeometry(.026,24),statusMat,card,[-4.16,-2.72,.32]);

// Minimal phone as a native 3D object, with a procedural screen rather than stock imagery.
const phone=new THREE.Group();scene.add(phone);phone.visible=false;
mesh(bodyGeometry(3.5,7.2,.43,.20,.055),metal,phone);
face(3.36,7.06,.38,black,phone,.16);
const screenCanvas=document.createElement('canvas');screenCanvas.width=700;screenCanvas.height=1440;
const sx=screenCanvas.getContext('2d');const screenTexture=new THREE.CanvasTexture(screenCanvas);screenTexture.colorSpace=THREE.SRGBColorSpace;
const screenMat=new THREE.MeshBasicMaterial({map:screenTexture});
const phoneScreen=face(3.20,6.80,.30,screenMat,phone,.169);
function phoneUI(t){
 const x=sx;x.fillStyle='#0c1017';x.fillRect(0,0,700,1440);
 const bg=x.createRadialGradient(600,300,0,400,500,900);bg.addColorStop(0,'#172535');bg.addColorStop(1,'#0b0f15');x.fillStyle=bg;x.fillRect(0,0,700,1440);
 x.fillStyle='#b6bfcc';x.font=`24px ${sans}`;x.fillText('09:41',52,70);
 x.fillStyle='#050608';x.beginPath();x.roundRect(268,36,164,40,22);x.fill();
 x.fillStyle='#8397ae';x.font=`20px ${mono}`;x.fillText('YUHUAN / MEMORY',52,220);
 x.fillStyle='#edf3f9';x.font=`500 54px ${sans}`;x.fillText('今天，已被记住。',50,308);
 x.fillStyle='#8c9bac';x.font=`25px ${sans}`;x.fillText('来自语环 X1 的生活片段',52,360);
 const cards=[{y:480,label:'一个想法',time:'10:32',title:'把灵感，留给下一次创造。',tag:'灵感整理',color:'#9bbcdc'},
 {y:735,label:'一件待办',time:'14:00',title:'周五的约定，记得提醒我。',tag:'提醒建议',color:'#cabd9b'},
 {y:990,label:'一段记忆',time:'18:26',title:'那些没有刻意记录的瞬间。',tag:'对话摘要',color:'#a5baa9'}];
 for(let i=0;i<cards.length;i++){
  const o=cards[i],a=smooth((t-40.5-i*.65)/1.1);x.save();x.globalAlpha=a;x.translate(0,(1-a)*22);
  x.fillStyle='#161f2b';x.beginPath();x.roundRect(36,o.y,628,208,24);x.fill();x.strokeStyle='#263141';x.lineWidth=1;x.stroke();
  x.fillStyle=o.color;x.font=`21px ${sans}`;x.fillText(o.label,64,o.y+45);x.textAlign='right';x.fillStyle='#768698';x.font=`20px ${mono}`;x.fillText(o.time,633,o.y+45);x.textAlign='left';
  x.fillStyle='#d8e2ec';x.font=`27px ${sans}`;x.fillText(o.title,64,o.y+100);
  x.fillStyle='#8b9bad';x.font=`20px ${sans}`;x.fillText(o.tag,64,o.y+159);x.restore();
 }
 x.fillStyle='#556779';x.font=`19px ${sans}`;x.textAlign='center';x.fillText('手机本地 AI · 界面概念',350,1340);x.fillStyle='#aab4bf';x.beginPath();x.roundRect(252,1390,196,6,3);x.fill();x.textAlign='left';
 screenTexture.needsUpdate=true;
}

const poses=[
 // t, position xyz, euler xyz, camera distance, fov, target xyz
 {t:0, p:[.8,-.1,0],r:[1.52,-.18,-.12],d:22,f:30,at:[0,0,0]},
 {t:2,p:[.7,0,0],r:[1.33,-.20,-.13],d:21,f:30,at:[0,0,0]},
 {t:6.6,p:[1.6,.1,0],r:[.32,-.34,-.10],d:24,f:31,at:[0,0,0]},
 {t:7,p:[3.7,-.6,0],r:[1.46,-.10,.10],d:24,f:32,at:[0,0,0],cut:true},
 {t:13.8,p:[3.4,-.6,0],r:[1.31,-.08,.07],d:24,f:32,at:[0,0,0]},
 {t:14,p:[3.6,.25,0],r:[.18,-.37,-.15],d:27,f:31,at:[0,0,0],cut:true},
 {t:22.8,p:[3.5,.25,0],r:[.12,-.27,-.10],d:25,f:31,at:[0,0,0]},
 {t:23,p:[-4.6,.8,0],r:[-.90,-.26,-.08],d:20,f:34,at:[0,0,0],cut:true},
 {t:30.8,p:[-4.4,.8,0],r:[-.76,-.22,-.06],d:20,f:34,at:[0,0,0]},
 {t:31,p:[3.9,0,0],r:[0,0,-.12],d:57,f:15,at:[0,0,0],cut:true},
 {t:34.4,p:[3.9,0,0],r:[.12,-.22,-.12],d:28,f:30,at:[0,0,0]},
 {t:38.8,p:[3.9,0,0],r:[.18,-.26,-.08],d:27,f:31,at:[0,0,0]},
 {t:39,p:[-4.3,-1.5,0],r:[.24,.34,-.09],d:28,f:31,at:[0,0,0],cut:true},
 {t:45.8,p:[-4.4,-1.4,0],r:[.20,.26,-.06],d:28,f:31,at:[0,0,0]},
 {t:46,p:[0,1.7,0],r:[.65,-.36,-.15],d:34,f:33,at:[0,0,0],cut:true},
 {t:53.99,p:[0,1.7,0],r:[.29,-.16,-.06],d:34,f:33,at:[0,0,0]}
];
function pose(t){
 let i=0;while(i<poses.length-1&&t>=poses[i+1].t)i++;
 let a=poses[i],b=poses[Math.min(i+1,poses.length-1)];let u=b.cut?0:smooth((t-a.t)/(b.t-a.t||1));
 let p=a.p.map((v,j)=>lerp(v,b.p[j],u)),r=a.r.map((v,j)=>lerp(v,b.r[j],u));
 card.position.set(...p);card.rotation.set(...r);card.scale.setScalar(1);
 camera.position.set(0,0,lerp(a.d,b.d,u));camera.fov=lerp(a.f,b.f,u);camera.lookAt(0,0,0);camera.updateProjectionMatrix();
 if(t>=31&&t<34.4){const mix=smooth((t-31)/3.4);const p=camera.projectionMatrix.elements,o=ortho.projectionMatrix.elements;for(let j=0;j<16;j++)p[j]=lerp(o[j]*camera.position.z,p[j],mix);camera.projectionMatrixInverse.copy(camera.projectionMatrix).invert();}
 const reveal=smooth(t/2.4);scene.environmentIntensity=lerp(.05,.72,reveal);ambient.intensity=lerp(.08,.65,reveal);key.intensity=lerp(.15,3.6,reveal);
 key.position.x=-7+Math.sin(t*.23)*7;strip.position.set(-8+Math.sin(t*.3)*6,-3,4);strip.intensity=2.3+.8*Math.sin(t*.47);rim.intensity=4.5;warm.intensity=.3;
 if(t<7){key.intensity*=.75;scene.environmentIntensity*=.8;}
 if(t>=7&&t<14){scene.environmentIntensity=.55;key.intensity=2.0;strip.intensity=4.8;strip.position.set(-10+(t-7)*3,-3,4);}
 phone.visible=t>=39&&t<46;
if(phone.visible)card.scale.setScalar(.78);
 if(phone.visible){phone.position.set(5.6,-.4,.4);phone.rotation.set(-.025,-.21+.035*Math.sin(t*.4),.035);phone.scale.setScalar(.92);phoneUI(t);}
 const wake=t>=34&&t<39;
 micLeds.forEach((m,i)=>{m.material.opacity=(t>=31&&t<39)?(i===0?.55:(wake?smooth((t-34)/.5)*.5:0)):0;});
 const press=(t>=25.4&&t<25.7)||(t>=27.6&&t<27.9)||(t>=28.1&&t<28.4);
 buttons[1].position.y=-3.98+(press?.055:0);statusMat.color.set(press?0xe5d4ac:0xb6e0fc);
 card.updateMatrixWorld(true);camera.updateMatrixWorld(true);
}
function project(x,y,z=.32,obj=card){const v=new THREE.Vector3(x,y,z);obj.localToWorld(v);v.project(camera);return [(v.x+1)*W/2,(1-v.y)*H/2];}

function text(str,x,y,size=30,color=WHITE,weight=400,spacing=0,align='left',font=sans){
 ctx.save();ctx.fillStyle=color;ctx.font=`${weight} ${size}px ${font}`;ctx.textAlign=align;ctx.textBaseline='alphabetic';
 if(spacing){let chars=Array.from(str),width=chars.reduce((s,c)=>s+ctx.measureText(c).width,0)+spacing*(chars.length-1);let px=x-(align==='center'?width/2:align==='right'?width:0);ctx.textAlign='left';for(const c of chars){ctx.fillText(c,px,y);px+=ctx.measureText(c).width+spacing;}}
 else ctx.fillText(str,x,y);ctx.restore();
}
function line(x1,y1,x2,y2,color='#526173',width=1){ctx.strokeStyle=color;ctx.lineWidth=width;ctx.beginPath();ctx.moveTo(x1,y1);ctx.lineTo(x2,y2);ctx.stroke();}
function glowDot(x,y,r=3,c='175,211,245',a=1){ctx.save();ctx.globalAlpha*=a;let g=ctx.createRadialGradient(x,y,0,x,y,r*12);g.addColorStop(0,`rgba(${c},.5)`);g.addColorStop(.15,`rgba(${c},.15)`);g.addColorStop(1,`rgba(${c},0)`);ctx.fillStyle=g;ctx.fillRect(x-r*12,y-r*12,r*24,r*24);ctx.fillStyle=`rgb(${c})`;ctx.beginPath();ctx.arc(x,y,r,0,Math.PI*2);ctx.fill();ctx.restore();}
function flare(x,y,a=1,len=460){
 ctx.save();ctx.globalCompositeOperation='screen';ctx.globalAlpha=a;
 let g=ctx.createLinearGradient(x-len,y,x+len,y);g.addColorStop(0,'rgba(129,177,235,0)');g.addColorStop(.4,'rgba(129,177,235,.04)');g.addColorStop(.5,'rgba(214,235,255,.75)');g.addColorStop(.6,'rgba(129,177,235,.04)');g.addColorStop(1,'rgba(129,177,235,0)');
 ctx.fillStyle=g;ctx.fillRect(x-len,y-.6,len*2,1.2);ctx.filter='blur(3px)';ctx.fillRect(x-len,y-1,len*2,2);ctx.filter='none';glowDot(x,y,2.4,'181,216,255',.8);ctx.restore();
}
function animatedText(str,x,y,size,t,delay=0,color=WHITE,weight=400,align='left'){
 const p=easeBezier((t-delay)/1.05);ctx.save();ctx.globalAlpha*=clamp(p);text(str,x,y+(1-elastic((t-delay)/1.15))*22,size,color,weight,0,align);ctx.restore();
}
function eyebrow(label,x,y,t){ctx.save();ctx.globalAlpha*=out(t/.8);text(label,x,y,13,MUTED,400,3);line(x,y+24,x+32*out(t),y+24,'#566679');ctx.restore();}
function sceneLayer(t,a,b,fn){let alpha=win(t,a,b,.62);if(alpha<.001)return;ctx.save();ctx.globalAlpha=alpha;fn(t-a);ctx.restore();}

function waveform(x,y,w,h,t,alpha=1,hot=.5){
 ctx.save();ctx.globalAlpha*=alpha;const count=128;for(let i=0;i<count;i++){
  const amp=(.10+.65*Math.pow(Math.abs(Math.sin(i*.34+t*.45)*Math.cos(i*.087-t*.09)),1.6))*(.5+.5*Math.sin(i*.071+1)**2);
  const bh=Math.max(2,h*amp);ctx.fillStyle=i/count<hot?'#b4ccdf':'#364454';ctx.fillRect(x+i*w/count,y-bh/2,2.2,bh);
 }ctx.restore();
}
function timeline(x,y,w,t,selected=0){
 line(x,y,x+w,y,'#38414d',1);
 for(let i=0;i<=24;i++){const xx=x+i*w/24;line(xx,y-4,xx,y+(i%6===0?13:6),i%6===0?'#687485':'#394350');if(i%6===0)text(String(i).padStart(2,'0'),xx,y+38,13,MUTED,400,1,'center',mono);}
 const ph=.15+.70*clamp(t/6);if(selected){const rw=w*selected/24;ctx.fillStyle='rgba(170,202,235,.12)';ctx.fillRect(x+w-rw,y-52,rw,52);line(x+w-rw,y-52,x+w,y-52,'#a5c7e7',1.5);}
 const xx=x+w*ph;line(xx,y-58,xx,y,'#b4d3ee',1);glowDot(xx,y-58,2);text('HOURS',x+w+32,y+4,11,'#657487',400,1.5,'left',mono);
}

function bg(t){
 ctx.fillStyle='#020304';ctx.fillRect(0,0,W,H);
 const g=ctx.createRadialGradient(1100+Math.sin(t*.1)*140,490,0,1100,490,850);g.addColorStop(0,'#0d131c');g.addColorStop(.45,'#070b11');g.addColorStop(1,'#020304');ctx.fillStyle=g;ctx.fillRect(0,TOP,W,BOTTOM-TOP);
 // Soft optical floor, deliberately below the enclosure's darkest surfaces.
 ctx.save();ctx.globalAlpha=.16;const haze=ctx.createRadialGradient(1100,760,0,1100,760,500);haze.addColorStop(0,'#42566f');haze.addColorStop(1,'rgba(5,8,12,0)');ctx.fillStyle=haze;ctx.translate(0,500);ctx.scale(1,.35);ctx.fillRect(0,0,W,1500);ctx.restore();
}

function graphics(t){
 sceneLayer(t,0,7,s=>{
   const a=win(s,1.0,6.85,.9);ctx.save();ctx.globalAlpha*=a;
   text('YUHUAN  /  PERSONAL MEMORY',W/2,240,13,'#8997aa',400,5,'center');
   animatedText('让此刻，成为记忆。',W/2,800,52,s,1.25,WHITE,300,'center');
   ctx.restore();
   const p=project(lerp(-4.6,4.6,clamp((s-.5)/4)),3.88,.30);flare(p[0],p[1],win(s,.5,4.8,1),700);
 });
 sceneLayer(t,7,14,s=>{
   eyebrow('01 / INDUSTRIAL PRECISION',150,254,s);
   animatedText('薄得，',150,370,76,s,.15,WHITE,300);animatedText('恰如其分。',150,466,76,s,.30,WHITE,300);
   animatedText('把存在感，留给声音。',154,539,23,s,.65,MUTED,300);
   const a=project(4.75,-3.83,-.3),b=project(4.75,-3.83,.3),p=out((s-.7)/1.6);ctx.save();ctx.globalAlpha*=p;
   const xx=Math.max(a[0],b[0])+70;
   line(a[0]+10,a[1],xx,a[1],'#687c95');line(b[0]+10,b[1],xx,b[1],'#687c95');line(xx-8,a[1],xx+8,a[1],'#acc5df');line(xx-8,b[1],xx+8,b[1],'#acc5df');line(xx,a[1],xx,lerp(a[1],b[1],p),'#9ab6d5');
   text('THIN BY DESIGN',xx+28,(a[1]+b[1])/2+4,12,'#92a9c3',400,2);ctx.restore();
   const point=project(lerp(-5,5,clamp((s-1)/5)),-3.98,.13);flare(point[0],point[1],win(s,.8,6.3,1)*.75,520);
 });
 sceneLayer(t,14,23,s=>{
   eyebrow('02 / ALWAYS IN THE MOMENT',150,250,s);
   ctx.save();ctx.globalAlpha*=out((s-.15)/1.1);text('24',140,471,180,WHITE,200,-6);text('H',390,466,58,'#879bb2',300);ctx.restore();
   animatedText('循环记录。',154,545,44,s,.45,WHITE,300);
   animatedText('让过去，随时在场。',155,595,23,s,.7,MUTED,300);
   ctx.save();ctx.globalAlpha*=out((s-.6)/1.2);waveform(154,724,600,78,s,.9,.12+.78*clamp(s/8));timeline(154,780,600,s);text('循环记录窗口',155,879,13,'#6d7c8e',400,1.5);ctx.restore();
   // 24 hours is a recording retention window, deliberately never labelled battery life.
 });
 sceneLayer(t,23,31,s=>{
   const x=1120;eyebrow('03 / GO BACK. KEEP IT.',x,260,s);
   animatedText('按一下。',x,374,68,s,.1,WHITE,300);animatedText('留住前一小时。',x,460,60,s,.30,WHITE,300);
   animatedText('不必提前，决定什么值得记住。',x+2,526,22,s,.6,MUTED,300);
   const n=s<2.4?0:s<4.6?1:s<5.1?2:3;
   ctx.save();ctx.globalAlpha*=out((s-1.0)/1.2);text(String(n).padStart(2,'0'),x+2,691,86,'#b8cfe7',200,1);text(n?'H / 已保护':'H / 回溯待命',x+137,687,17,'#8c9fb6',400,2);
   text('连按 N 次，保存前 N 小时',x+2,752,18,MUTED,300);ctx.restore();
   const p=project(-2.09,-4.03,.05);const pulse=Math.exp(-Math.pow((s-2.5)/.25,2))+.75*Math.exp(-Math.pow((s-4.75)/.16,2))+.75*Math.exp(-Math.pow((s-5.25)/.16,2));
   ctx.save();ctx.globalAlpha*=clamp(pulse);glowDot(p[0],p[1],4,'222,207,171');ctx.strokeStyle='#d1c3a6';ctx.lineWidth=1;for(let i=0;i<2;i++){ctx.beginPath();ctx.ellipse(p[0],p[1],24+i*18,10+i*8,0,0,Math.PI*2);ctx.stroke();}ctx.restore();
   ctx.save();ctx.globalAlpha*=out((s-1.0)/1.0)*.7;line(p[0]+30,p[1],995,p[1],'#6a7787');line(995,p[1],1048,686,'#6a7787');line(1048,686,1080,686,'#6a7787');ctx.restore();
 });
 sceneLayer(t,31,39,s=>{
   eyebrow('04 / INTELLIGENT LISTENING',150,250,s);
   animatedText('安静时，',150,375,64,s,.1,WHITE,300);animatedText('一麦倾听。',150,456,64,s,.3,WHITE,300);
   const active=smooth((s-3)/.6);ctx.save();ctx.globalAlpha*=out((s-.7)/1.1);text('人声起，四麦响应。',154,538,25,lerpColor('#677689','#c8d5e3',active),300);ctx.restore();
   ctx.save();ctx.globalAlpha*=out((s-.8));text(active>.5?'04 / VOICE ACTIVE':'01 / LOW POWER',154,670,14,BLUE,400,3,'left',mono);line(154,695,500,695,'#2b384a');waveform(154,741,350,64,s,.65,active>.5?.9:.25);ctx.restore();
   for(let i=0;i<4;i++){
     const [x,y]=project(...micPositions[i]);const strength=i===0?.8:active*.72;ctx.save();ctx.globalAlpha*=strength;
     for(let k=0;k<3;k++){const ph=((s*.5+k/3+i*.12)%1),r=14+ph*48;ctx.globalAlpha=strength*(1-ph)*.6;ctx.strokeStyle='#a1c8e9';ctx.lineWidth=.85;ctx.beginPath();ctx.ellipse(x,y,r,r*.88,-.08,0,Math.PI*2);ctx.stroke();}glowDot(x,y,2.0,'175,213,245',strength);ctx.restore();
   }
   ctx.save();ctx.globalAlpha*=smooth((s-3.2)/1);const a=project(...micPositions[0]),b=project(...micPositions[1]);line(a[0]+18,a[1]-23,b[0]-18,b[1]-23,'#556c88',.6);text('ONE CLOCK. FOUR VOICES.',(a[0]+b[0])/2,(a[1]+b[1])/2-44,11,'#829ab5',400,2,'center',mono);ctx.restore();
 });
 sceneLayer(t,39,46,s=>{
   eyebrow('05 / FROM MEMORY TO MEANING',150,234,s);
   animatedText('让记录，成为下一步。',150,328,50,s,.15,WHITE,300);
   animatedText('Wi-Fi / 蓝牙同步 · 手机本地 AI',154,382,20,s,.5,MUTED,300);
   ctx.save();ctx.globalAlpha*=out((s-1)/1.2);
   text('灵感整理',1210,888,16,'#94a4b8',300,2);text('提醒建议',1380,888,16,'#94a4b8',300,2);text('功能愿景',1540,888,12,'#6d8099',400,2);ctx.restore();
   const a=project(5.2,0),b=project(-1.8,0,.17,phone);
   ctx.save();ctx.globalAlpha*=win(s,1,6.9,.8)*.7;
   ctx.strokeStyle='#3d5570';ctx.lineWidth=1;ctx.setLineDash([2,8]);ctx.beginPath();ctx.moveTo(...a);ctx.bezierCurveTo(a[0]+100,a[1]-90,b[0]-120,b[1]-60,...b);ctx.stroke();ctx.setLineDash([]);
   for(let i=0;i<5;i++){let p=((s*.35+i*.20)%1),v=1-p;const x=v*v*v*a[0]+3*v*v*p*(a[0]+100)+3*v*p*p*(b[0]-120)+p*p*p*b[0];const y=v*v*v*a[1]+3*v*v*p*(a[1]-90)+3*v*p*p*(b[1]-60)+p*p*p*b[1];glowDot(x,y,1.8,'165,199,232',.8);}
   text('SYNC TO PHONE',(a[0]+b[0])/2,(a[1]+b[1])/2+50,11,'#7f96b1',400,2,'center',mono);ctx.restore();
 });
 sceneLayer(t,46,54,s=>{
   ctx.save();ctx.globalAlpha*=out((s-.55)/1.6);text('语环',W/2-46,785,76,WHITE,300,5,'right');text('X1',W/2-15,785,82,WHITE,200,1,'left');ctx.restore();
   animatedText('轻薄随身。记忆随行。',W/2,850,22,s,1.15,'#a5b1c0',300,'center');
   ctx.save();ctx.globalAlpha*=smooth((s-2)/1);text('YUHUAN  /  YOUR LIFE, REMEMBERED.',W/2,253,12,'#7c8ca2',400,4,'center');ctx.restore();
   ctx.save();ctx.globalAlpha*=smooth((s-3)/1);text('工业外观概念 · 手机 AI 为功能愿景 · 24H 指循环记录窗口',W/2,919,12,'#5f6d7f',400,1,'center');ctx.restore();
   const p=project(lerp(-5,5,clamp((s-.2)/5)),-3.94,.28);flare(p[0],p[1],win(s,.3,5.8,1)*.4,500);
 });
}

function lerpColor(a,b,t){let c=new THREE.Color(a).lerp(new THREE.Color(b),t);return '#'+c.getHexString();}

// Deterministic fine film grain, precomputed once and shifted instead of random per render.
const grain=document.createElement('canvas');grain.width=256;grain.height=256;const gx=grain.getContext('2d');const gi=gx.createImageData(256,256),random=seeded(20261018);
for(let i=0;i<gi.data.length;i+=4){const n=random()*255;gi.data[i]=gi.data[i+1]=gi.data[i+2]=n;gi.data[i+3]=255;}gx.putImageData(gi,0,0);
const pattern=ctx.createPattern(grain,'repeat');

export function render(t){
 t=clamp(t,0,DURATION-.0001);pose(t);bg(t);
 ctx.save();ctx.beginPath();ctx.rect(0,TOP,W,BOTTOM-TOP);ctx.clip();
 renderer.render(scene,camera);ctx.drawImage(renderer.domElement,0,0,W,H);
 // Faint highlight bloom from the rendered source, restricted to the metal silhouette.
 // Luminance is preserved by screen blending at only 4%; no haze across the typography.
 ctx.save();ctx.globalAlpha=.035;ctx.globalCompositeOperation='screen';ctx.filter='blur(10px)';ctx.drawImage(renderer.domElement,0,0,W,H);ctx.restore();
 graphics(t);
 ctx.save();ctx.globalAlpha=.023;ctx.globalCompositeOperation='soft-light';ctx.fillStyle=pattern;ctx.translate(Math.floor(t*24)%256,Math.floor(t*17)%256);ctx.fillRect(-256,-256,W+512,H+512);ctx.restore();
 const vignette=ctx.createRadialGradient(W/2,H/2,300,W/2,H/2,1100);vignette.addColorStop(0,'rgba(0,0,0,0)');vignette.addColorStop(1,'rgba(0,0,0,.43)');ctx.fillStyle=vignette;ctx.fillRect(0,TOP,W,BOTTOM-TOP);ctx.restore();
 // Proper letterbox and quiet, consistent corner signatures.
 ctx.fillStyle='#020304';ctx.fillRect(0,0,W,TOP);ctx.fillRect(0,BOTTOM,W,H-BOTTOM);
 const footer=win(t,.2,53.9,.7);ctx.save();ctx.globalAlpha=footer;
 text('语环 X1',70,76,14,'#77808c',400,2);text('PRODUCT CONCEPT / 2026',W-70,76,10,'#4d5969',400,2,'right',mono);
 const chapter=Math.max(0,CHAPTERS.findLastIndex(s=>t>=s));text(`${String(chapter+1).padStart(2,'0')} / 07`,W-70,1018,10,'#465363',400,2,'right',mono);
 ctx.restore();
 const fade=smooth(t/.9)*smooth((54-t)/1.3);if(fade<1){ctx.fillStyle=`rgba(2,3,4,${1-fade})`;ctx.fillRect(0,0,W,H);}
 return t;
}

const score=document.querySelector('#score'),play=document.querySelector('#play'),sound=document.querySelector('#sound'),seek=document.querySelector('#seek');
let running=false,current=0,start=0,audioEnabled=false;
function updateUI(){seek.value=current;seek.style.setProperty('--progress',`${current/DURATION*100}%`);document.querySelector('#time').textContent=`00:${Math.floor(current).toString().padStart(2,'0')} / 00:54`;}
function setPlaying(value){
 if(value&&current>=DURATION-.1)current=0;
 running=value;start=performance.now()-current*1000;document.body.classList.toggle('paused',!running);play.setAttribute('aria-label',running?'暂停':'播放');play.innerHTML=running?'<svg viewBox="0 0 24 24"><path d="M7 5h4v14H7zm6 0h4v14h-4z"/></svg>':'<svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>';
 if(audioEnabled){score.currentTime=current;if(running)score.play().catch(()=>{});else score.pause();}
}
function seekTo(t){current=clamp(t,0,DURATION-.001);start=performance.now()-current*1000;score.currentTime=current;render(current);updateUI();}
play.onclick=()=>{if(!audioEnabled){audioEnabled=true;sound.style.opacity=1;}setPlaying(!running);};
sound.style.opacity=.45;
sound.onclick=()=>{audioEnabled=!audioEnabled;sound.style.opacity=audioEnabled?1:.45;sound.setAttribute('aria-label',audioEnabled?'关闭声音':'开启声音');if(audioEnabled&&running){score.currentTime=current;score.play().catch(()=>{});}else score.pause();};
seek.oninput=()=>seekTo(Number(seek.value));
document.querySelector('#fullscreen').onclick=()=>document.fullscreenElement?document.exitFullscreen():document.documentElement.requestFullscreen();
document.addEventListener('keydown',e=>{if(e.target===seek)return;if(e.code==='Space'){e.preventDefault();play.click();}else if(e.code==='ArrowRight'){e.preventDefault();seekTo(CHAPTERS.find(t=>t>current+.5)??46);}else if(e.code==='ArrowLeft'){e.preventDefault();seekTo([...CHAPTERS].reverse().find(t=>t<current-.5)??0);}else if(e.key.toLowerCase()==='f')document.querySelector('#fullscreen').click();});
canvas.addEventListener('click',()=>play.click());
document.addEventListener('visibilitychange',()=>{if(document.hidden&&running)setPlaying(false);});
function tick(now){if(running){current=(now-start)/1000;if(current>=DURATION){current=DURATION-.001;setPlaying(false);}render(current);updateUI();}requestAnimationFrame(tick);}
await document.fonts.ready;
render(capture?3.5:4.3);
document.querySelector('#loading').classList.add('done');
if(capture){document.querySelector('.controls').style.display='none';document.querySelector('.hint').style.display='none';document.querySelector('#loading').style.display='none';}
else {current=0;requestAnimationFrame(tick);}
window.film={render,seekTo,duration:DURATION,chapters:CHAPTERS,ready:true,canvas,renderer,scene,camera};
