# 语环 X1 · 让此刻，成为记忆。

![影片封面](assets/poster.jpg)

54 秒原创代码产品概念短片，1920×1080、30fps，2.35:1 画面置于 16:9 容器。深黑背景、石墨金属、冷白轮廓光、横向眩光、微距、正交到透视过渡，以及高阻尼文字动效。配乐与按键声由代码合成，无第三方音乐采样。

## 播放

直接播放单独交付的 MP4。查看实时版本时，在本目录运行：

```sh
python3 -m http.server 8765 --bind 127.0.0.1
```

浏览器打开 `http://127.0.0.1:8765`，点击播放即可。空格暂停/继续，左右方向键切换章节，F 全屏。所有库、配乐、模型与画面都在本地；无需服务器账号、API 密钥或远程字体。首次点击播放会开启配乐，可用声音按钮静音。系统设置减少动态效果时，影片保持暂停，等待主动播放。

## 分镜

| 时间 | 画面 | 核心信息 |
|---|---|---|
| 00–07 | 黑场中边缘扫光，缓慢翻转显露机身 | 让此刻，成为记忆 |
| 07–14 | 侧边微距、激光扫光、厚度指示线 | 超薄卡片形态，不标未确认的毫米数 |
| 14–23 | 连续波形与 24 小时时间轴 | 循环记录窗口，非续航承诺 |
| 23–31 | 回溯键微距、触觉音效与 01 / 02 / 03 H | 按一次保留前一小时，连按保存多小时 |
| 31–39 | 正交到透视、四个声孔的唤醒光环 | 安静时一麦，人声触发四麦，同源时钟 |
| 39–46 | 录音卡向手机传输，记忆卡片逐一出现 | 手机同步及本地 AI 的功能愿景 |
| 46–54 | 金属机身收尾，语环 X1 字标渐现 | 轻薄随身，记忆随行 |

## 修改与重新导出

- `film.js`：产品几何、材质、时钟、镜头、灯光、文字与逐帧合成。`poses` 控制镜头；`graphics()` 控制分镜文案。`window.film.render(seconds)` 可确定性定位到任意时间。
- `index.html`：响应式播放器和键盘控制。
- `assets/score.m4a`：已混音的原创立体声配乐。
- `tools/make_score.py`：原创合成配乐源代码，需要 Python 与 NumPy。
- `tools/render.mjs`：隔离的无头浏览器逐帧导出 MP4，不访问现有浏览器标签。
- `vendor/`：Three.js 0.180.0 原版压缩库与 MIT 许可。

重新导出需 Node.js、FFmpeg、Playwright 及支持 WebGL 的 Chromium。此交付已在 macOS + Chrome + Metal 环境导出。先安装渲染依赖：

```sh
npm install
npx playwright install chromium
npm run render -- --out ../语环X1-产品概念片.mp4
```

使用已安装的 Chrome 时，可跳过浏览器下载并指定：

```sh
npm run render -- --chrome '/Applications/Google Chrome.app/Contents/MacOS/Google Chrome' --out ../语环X1-产品概念片.mp4
```

`--fps 30` 默认完整导出；`--seconds 3` 可渲染前三秒快速检查。渲染器会同时生成封面及 `render-report.json`。Three.js 已随包附带，普通播放不需要 npm install。若浏览器/操作系统不同，字体和 GPU 的渲染可能有细微差别。

重建配乐：

```sh
python3 -m pip install numpy
python3 tools/make_score.py score.wav
ffmpeg -y -i score.wav -af loudnorm=I=-19:TP=-1.5:LRA=9 -ar 48000 -c:a aac -b:a 192k assets/score.m4a
```

## 设计与产品口径

外壳为本次新建的工业设计概念，参考录音卡、四角声孔和双按键需求；不是经结构验证的外壳 CAD，外壳尺寸、实际厚度、材料和表面工艺尚未定版。视频未使用苹果或索尼标识、广告素材或音乐。

片中“24H”表示循环记录保留窗口；不表示已测得 24 小时电池续航。手机 AI、提醒和界面属于后续功能愿景。已交付固件是单声道录音，影片没有宣称已完成立体声校准、波束成形或量产验证。四麦光环是工作模式的视觉示意，并非声学仿真。

本次新写的影片与音乐源码可供本产品修改、使用及宣传。第三方 Three.js 保留其原许可，见 `vendor/THREE-LICENSE.txt`。
