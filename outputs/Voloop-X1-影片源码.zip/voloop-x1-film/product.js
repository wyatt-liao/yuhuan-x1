import * as THREE from './vendor/three.module.min.js';
import {PCB} from './product-data.js';

// All XY coordinates use the same rigid transform of the real PCB. One unit = 10 mm.
const clamp=(v,a=0,b=1)=>Math.max(a,Math.min(b,v));
const lerp=(a,b,t)=>a+(b-a)*t;
const smooth=t=>{t=clamp(t);return t*t*(3-2*t);};
const sans='-apple-system, BlinkMacSystemFont, "Helvetica Neue", "PingFang SC", sans-serif';
const brand='"Avenir Next", "Helvetica Neue", sans-serif';
function rounded(w,h,r){
 const x=-w/2,y=-h/2,s=new THREE.Shape();
 s.moveTo(x+r,y);s.lineTo(x+w-r,y);s.quadraticCurveTo(x+w,y,x+w,y+r);
 s.lineTo(x+w,y+h-r);s.quadraticCurveTo(x+w,y+h,x+w-r,y+h);
 s.lineTo(x+r,y+h);s.quadraticCurveTo(x,y+h,x,y+h-r);s.lineTo(x,y+r);s.quadraticCurveTo(x,y,x+r,y);return s;
}
function hole(x,y,r){const p=new THREE.Path();p.absarc(x,y,r,0,Math.PI*2,true);return p;}
function solid(w,h,r,d,b=.03){const g=new THREE.ExtrudeGeometry(rounded(w,h,r),{depth:d,bevelEnabled:b>0,bevelSegments:4,steps:1,bevelSize:b,bevelThickness:b,curveSegments:22});g.translate(0,0,-d/2);return g;}
function mesh(g,m,parent,p=[0,0,0]){const obj=new THREE.Mesh(g,m);obj.position.set(...p);parent.add(obj);return obj;}
function plane(shape,material,parent,z,w,h){
 const g=new THREE.ShapeGeometry(shape,48),uv=g.attributes.uv;
 for(let i=0;i<uv.count;i++)uv.setXY(i,uv.getX(i)/w+.5,uv.getY(i)/h+.5);
 return mesh(g,material,parent,[0,0,z]);
}
function texture(canvas){const t=new THREE.CanvasTexture(canvas);t.colorSpace=THREE.SRGBColorSpace;t.anisotropy=8;return t;}
function outline(w,h,r,z,color,alpha=.45){return new THREE.LineLoop(new THREE.BufferGeometry().setFromPoints(rounded(w,h,r).getPoints(120).map(v=>new THREE.Vector3(v.x,v.y,z))),new THREE.LineBasicMaterial({color,transparent:true,opacity:alpha}));}

export class ProductStudio {
 constructor(){
  this.renderer=new THREE.WebGLRenderer({alpha:true,antialias:true,preserveDrawingBuffer:true,powerPreference:'high-performance'});
  this.renderer.setSize(1920,1080);this.renderer.setPixelRatio(1);this.renderer.setClearColor(0,0);
  this.renderer.outputColorSpace=THREE.SRGBColorSpace;this.renderer.toneMapping=THREE.ACESFilmicToneMapping;
  this.renderer.toneMappingExposure=1.12;
  this.scene=new THREE.Scene();this.camera=new THREE.PerspectiveCamera(34,16/9,.1,160);
  this.scene.add(new THREE.HemisphereLight(0xdde8fa,0x202128,.85));
  this.key=this.light(0xf3f6ff,4,[-5,7,10]);this.rim=this.light(0xa1bfe5,3.5,[8,-2,-5]);
  this.strip=this.light(0xfaf2e4,2.4,[-7,-5,3]);this.light(0xd5e2f4,1.3,[0,1,9]);
  this.environment();this.materials();this.buildCard();this.buildPhone();this.buildBoard();
 }
 light(color,intensity,p){const l=new THREE.DirectionalLight(color,intensity);l.position.set(...p);this.scene.add(l);return l;}
 environment(){
  const c=document.createElement('canvas');c.width=1024;c.height=512;const x=c.getContext('2d');
  x.fillStyle='#151a23';x.fillRect(0,0,1024,512);
  for(const [a,b,w,h,color]of [[220,155,250,100,'#edf2fa'],[760,240,120,190,'#bad1ed'],[470,390,420,12,'#f4f8ff'],[45,260,35,210,'#7086a2']]){
   x.fillStyle=color;x.filter='blur(10px)';x.fillRect(a-w/2,b-h/2,w,h);x.filter='none';
  }
  const t=texture(c);t.mapping=THREE.EquirectangularReflectionMapping;const pm=new THREE.PMREMGenerator(this.renderer);this.scene.environment=pm.fromEquirectangular(t).texture;t.dispose();pm.dispose();this.scene.environmentIntensity=.8;
 }
 materials(){
  const c=document.createElement('canvas');c.width=1024;c.height=1024;const x=c.getContext('2d');x.fillStyle='#bbbfc5';x.fillRect(0,0,1024,1024);
  let seed=123;for(let i=0;i<1024;i++){seed=(Math.imul(seed,1664525)+1013904223)|0;const n=(seed>>>0)/4294967296;x.strokeStyle=`rgba(0,0,0,${.015+n*.045})`;x.lineWidth=.5;x.beginPath();x.moveTo(0,i);x.lineTo(1024,i);x.stroke();}
  this.metal=new THREE.MeshPhysicalMaterial({color:0x8e96a1,metalness:1,roughness:.22,clearcoat:.3,envMapIntensity:1});
  this.graphite=new THREE.MeshPhysicalMaterial({color:0x3b3b3f,map:texture(c),metalness:.82,roughness:.38,clearcoat:.25,clearcoatRoughness:.38,envMapIntensity:.8});
  this.black=new THREE.MeshStandardMaterial({color:0x030507,roughness:.52,metalness:.25});
  this.capMaterial=new THREE.MeshPhysicalMaterial({color:0x55555b,metalness:.93,roughness:.26,clearcoat:.25});
 }
 buildCard(){
  const card=this.card=new THREE.Group();this.scene.add(card);
  // Main shell: exactly 6 mm visual envelope, including flush controls; mechanical target only.
  mesh(solid(10.23,7.63,.29,.43,.035),this.metal,card);
  const front=rounded(10.22,7.62,.28);for(const b of PCB.buttons)front.holes.push(hole(...b.modelXY,.253));
  plane(front,this.graphite,card,.273,10.22,7.62);
  const back=rounded(10.22,7.62,.28);for(const mic of PCB.microphones)back.holes.push(hole(...mic.modelXY,.067));
  plane(back,new THREE.MeshPhysicalMaterial({color:0x303034,metalness:.85,roughness:.39,side:THREE.DoubleSide}),card,-.295,10.22,7.62);
  card.add(outline(10.25,7.65,.29,.265,0xd3ddea,.43));card.add(outline(10.25,7.65,.29,-.265,0x9bafca,.4));
  this.frontFaces=[];
  const decalCanvas=document.createElement('canvas');decalCanvas.width=2048;decalCanvas.height=1536;const d=decalCanvas.getContext('2d');
  function at(x,y){return [(x/10.22+.5)*2048,(.5-y/7.62)*1536];}
  d.fillStyle='#bfc0c5';d.font=`400 92px ${brand}`;d.letterSpacing='-2px';d.fillText('Voloop',146,1280);
  const decal=mesh(new THREE.PlaneGeometry(10.22,7.62),new THREE.MeshBasicMaterial({map:texture(decalCanvas),transparent:true,depthWrite:false}),card,[0,0,.275]);
  this.buttons=[];
  PCB.buttons.forEach((b,i)=>{
   const [x,y]=b.modelXY;
   mesh(new THREE.CircleGeometry(.251,64),this.black,card,[x,y,.260]);
   mesh(new THREE.RingGeometry(.229,.253,72),this.metal,card,[x,y,.275]);
   const cap=new THREE.Group();cap.position.set(x,y,.279);card.add(cap);
   const body=mesh(new THREE.CylinderGeometry(.222,.224,.038,72),this.capMaterial,cap);body.rotation.x=Math.PI/2;
   if(i===0)mesh(new THREE.CircleGeometry(.038,32),new THREE.MeshBasicMaterial({color:0xbd6055}),cap,[0,0,.020]);
   else{
    const path=new THREE.Shape();path.moveTo(-.046,.061);path.lineTo(.046,.061);path.lineTo(.046,-.063);path.lineTo(0,-.027);path.lineTo(-.046,-.063);path.closePath();
    mesh(new THREE.ShapeGeometry(path),new THREE.MeshBasicMaterial({color:0xc9d9e9}),cap,[0,0,.021]);
   }
   cap.userData={designator:b.designator,baseZ:.279};this.buttons.push(cap);
  });
  this.micRims=[];
  PCB.microphones.forEach(m=>{
   const [x,y]=m.modelXY;const disc=mesh(new THREE.CircleGeometry(.066,48),this.black,card,[x,y,-.298]);disc.rotation.y=Math.PI;
   const ring=mesh(new THREE.RingGeometry(.067,.092,48),this.capMaterial,card,[x,y,-.2995]);ring.rotation.y=Math.PI;this.micRims.push(ring);
   // Fine acoustic mesh, aligned to the actual footprint's all-layer sound opening.
   for(const [a,b]of [[-.022,0],[.022,0],[0,.022],[0,-.022]]){
    const dot=mesh(new THREE.CircleGeometry(.006,8),new THREE.MeshBasicMaterial({color:0x667385}),card,[x+a,y+b,-.300]);dot.rotation.y=Math.PI;
   }
  });
  const bc=document.createElement('canvas');bc.width=2048;bc.height=1536;const bx=bc.getContext('2d');bx.textAlign='center';bx.fillStyle='#717177';bx.font=`400 44px ${brand}`;bx.letterSpacing='-1px';bx.fillText('Voloop',1024,1270);
  const backLogo=mesh(new THREE.PlaneGeometry(10.22,7.62),new THREE.MeshBasicMaterial({map:texture(bc),transparent:true,depthWrite:false}),card,[0,0,-.299]);backLogo.rotation.y=Math.PI;
  // Connector openings are on the correct edges, with their tangential coordinates from PCB1.
  const usb=new THREE.Group();usb.position.set(5.153,PCB.usb.modelXY[1],-.025);usb.rotation.set(0,Math.PI/2,Math.PI/2);card.add(usb);
  plane(rounded(.91,.29,.135),this.metal,usb,.003,.91,.29);plane(rounded(.82,.21,.10),this.black,usb,.007,.82,.21);
  plane(rounded(.56,.033,.015),new THREE.MeshStandardMaterial({color:0x69768a,metalness:.8,roughness:.35}),usb,.011,.56,.033);
  const sd=new THREE.Group();sd.position.set(PCB.sd.modelXY[0],-3.851,-.025);sd.rotation.x=Math.PI/2;card.add(sd);plane(rounded(1.28,.105,.04),this.black,sd,.003,1.28,.105);
  // Front face and control caps remain independently addressable for the alignment view.
  this.frontFaces=[decal];
 }
 buildBoard(){
  const board=this.board=new THREE.Group();this.card.add(board);board.visible=false;
  const shape=new THREE.Shape();PCB.board.outlineXY.forEach(([x,y],i)=>i?shape.lineTo(x,y):shape.moveTo(x,y));shape.closePath();
  mesh(new THREE.ExtrudeGeometry(shape,{depth:.065,bevelEnabled:false}),new THREE.MeshStandardMaterial({color:0x122b2b,metalness:.3,roughness:.55}),board,[0,0,-.04]);
  PCB.components.forEach(c=>{
   const [x,y]=c.xy,ww=Math.max(.06,c.bboxMm.x/10),hh=Math.max(.05,c.bboxMm.y/10);
   const isModule=c.designator==='U1',isSwitch=c.designator.startsWith('SW'),isConnector=c.designator==='J1'||c.designator==='J2';
   const mat=new THREE.MeshStandardMaterial({color:isModule||isConnector?0x8793a1:isSwitch?0xbac4ce:0x28313a,metalness:isModule||isConnector?.8:.2,roughness:.36});
   mesh(new THREE.BoxGeometry(ww,hh,isModule?.12:.035),mat,board,[x,y,.04]);
  });
 }
 buildPhone(){
  const p=this.phone=new THREE.Group();this.scene.add(p);p.visible=false;
  mesh(solid(3.5,7.2,.43,.20,.045),this.metal,p);plane(rounded(3.36,7.06,.38),this.black,p,.151,3.36,7.06);
  this.screenCanvas=document.createElement('canvas');this.screenCanvas.width=700;this.screenCanvas.height=1440;this.screenTexture=texture(this.screenCanvas);
  plane(rounded(3.2,6.80,.30),new THREE.MeshBasicMaterial({map:this.screenTexture}),p,.157,3.2,6.8);
 }
 phoneUI(t){
  const x=this.screenCanvas.getContext('2d');x.fillStyle='#111114';x.fillRect(0,0,700,1440);
  const g=x.createRadialGradient(630,300,0,500,400,950);g.addColorStop(0,'#29292f');g.addColorStop(1,'#111114');x.fillStyle=g;x.fillRect(0,0,700,1440);
  x.fillStyle='#bfc9d5';x.font=`24px ${sans}`;x.fillText('09:41',52,70);x.fillStyle='#050608';x.beginPath();x.roundRect(268,35,164,40,22);x.fill();
  x.fillStyle='#a0a0a7';x.font=`400 34px ${brand}`;x.fillText('Voloop',52,210);x.fillStyle='#f5f5f7';x.font=`400 52px ${sans}`;x.fillText('记忆，开始有用。',50,305);
  x.fillStyle='#93a5bb';x.font=`24px ${sans}`;x.fillText('来自 Voloop X1 的片段',52,360);
  const cards=[{at:22,y:470,k:'灵感',s:'把灵感，留给下一次创造。',c:'#aac9e7'},
   {at:23.25,y:740,k:'待办',s:'周五，把方案发给同事。',c:'#d4c8a8'},
   {at:24.5,y:1010,k:'提醒',s:'周五 14:00，记得赴约。',c:'#a7c7b9'}];
  for(const o of cards){let a=smooth((t-o.at)/.38);x.save();x.globalAlpha=a;x.translate(0,(1-a)*40);x.fillStyle='#28282e';x.beginPath();x.roundRect(36,o.y,628,218,24);x.fill();x.strokeStyle='#3b3b42';x.lineWidth=1;x.stroke();x.fillStyle=o.c;x.font=`24px ${sans}`;x.fillText(o.k,65,o.y+49);x.fillStyle='#e2eaf5';x.font=`28px ${sans}`;x.fillText(o.s,65,o.y+113);x.fillStyle='#8599af';x.font=`21px ${sans}`;x.fillText('整理自最近保存的录音',65,o.y+170);x.restore();}
  x.textAlign='center';x.fillStyle='#7e91a9';x.font=`19px ${sans}`;x.fillText('手机 AI · 功能愿景',350,1350);x.fillStyle='#aeb9c7';x.beginPath();x.roundRect(252,1390,196,6,3);x.fill();x.textAlign='left';this.screenTexture.needsUpdate=true;
 }
 configure(shot,t){
  this.card.visible=shot!=='none';this.phone.visible=shot==='phone';this.board.visible=shot==='alignment';
  this.card.position.set(0,0,0);this.card.rotation.set(0,0,0);this.card.scale.setScalar(1);
  this.buttons.forEach((b,i)=>{const pulse=i===1?Math.max(0,...[10.95,13.10,13.32,13.54].map(v=>1-Math.abs(t-v)/.10)):0;b.position.z=b.userData.baseZ-.020*pulse;});
  this.camera.fov=34;this.camera.position.set(0,0,24);this.camera.lookAt(0,0,0);
  if(shot==='reveal'){
   const s=smooth((t-6)/1.0);this.card.position.set(2.6,-.6,0);this.card.rotation.set(lerp(1.35,-.12,s),lerp(-.45,-.21,s),lerp(-.16,.055,s));this.camera.position.z=24.5;
  }else if(shot==='hero'){
   this.card.position.set(3.7,-.05,0);this.card.rotation.set(-.12+.035*Math.sin(t*.5),-.30+.10*Math.sin(t*.38),.06);this.camera.position.z=26;
  }else if(shot==='button'){
   this.camera.fov=30;this.camera.position.set(2.55,6.1,7.15);this.camera.lookAt(2.50,2.20,0);this.card.rotation.z=.02;
  }else if(shot==='loop'){
   this.card.position.set(4.3,.20,0);this.card.rotation.set(.08,-.21,-.07);this.card.scale.setScalar(.83);this.camera.position.z=26;
  }else if(shot==='phone'){
   this.card.position.set(-4.7,-1.45,0);this.card.rotation.set(.15,.25,-.06);this.card.scale.setScalar(.65);this.camera.position.z=27;
   this.phone.position.set(5.20,-.25,.2);this.phone.rotation.set(-.02,-.20,.025);this.phone.scale.setScalar(1.12);this.phoneUI(t);
  }else if(shot==='thin'){
   this.card.position.set(3.5,-.65,0);this.card.rotation.set(1.48,-.035,.055);this.camera.position.z=23;
  }else if(shot==='mics'){
   this.card.position.set(3.5,-.15,0);this.card.rotation.set(.09,Math.PI+.18,-.06);this.camera.position.z=26;
  }else if(shot==='alignment'){
   this.card.rotation.set(0,0,0);this.camera.position.set(0,0,25);this.camera.fov=24;
  }
  this.camera.updateProjectionMatrix();this.camera.updateMatrixWorld(true);this.card.updateMatrixWorld(true);
  this.key.position.x=-6+Math.sin(t*.75)*5;this.key.intensity=3.8;this.strip.position.set(-7+Math.sin(t*1.3)*4,-5,4);this.strip.intensity=2.8;this.rim.intensity=4;
  if(shot==='thin'){this.strip.position.set(-10+(t-27)*10,-3,3);this.strip.intensity=5.0;}
  if(shot==='button'){this.key.position.set(1,6,10);this.key.intensity=4.4;this.scene.environmentIntensity=.9;}
  else this.scene.environmentIntensity=.8;
 }
 render(shot,t){this.configure(shot,t);this.renderer.render(this.scene,this.camera);return this.renderer.domElement;}
 point(x,y,z=.3,obj=this.card){const v=new THREE.Vector3(x,y,z);obj.localToWorld(v);v.project(this.camera);return [(v.x+1)*960,(1-v.y)*540];}
 buttonPoint(i=1){return this.point(...PCB.buttons[i].modelXY,.30);}
 micPoint(i){return this.point(...PCB.microphones[i].modelXY,-.301);}
 phonePoint(x=0,y=0){return this.point(x,y,.16,this.phone);}
}
