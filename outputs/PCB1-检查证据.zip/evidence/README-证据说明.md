**PCB1 只读检查证据**

审查结论和解释见压缩包内 `PCB1-投产前审查.md`。原始文件未改写。

- `pcb-initial.json` / `pcb-final.json`：现场起止快照，仅采集时间和请求元数据变化，设计语义相同。
- `*.capture.json`：采集身份、范围和每次请求的原始哈希。
- `pcb-drc*.json`：原生 PCB DRC；`sch-drc-all.json`：原生原理图 DRC 汇总。
- `sch-P1.json` 至 `sch-P4.json`：逐页原理图原始读取。
- `connectivity-P*.json` / `reconciliation.json`：连接读取和逐脚对账。
- `path-*`：现场路径查询。`path-U3-*.json` 虽为此扩展名，内容是 CLI 原样文本。
- `path-U3-OUT.json`：不包含铺铜的路径未找到，不等于开路。
- `pcb-check.json`：辅助规则检查，警告不全是真缺陷；须结合报告解释。
- `pcb-layout-lint.json`：多边形焊盘覆盖不完整；其评分和飞线交叉数未作为短路证据。
- `project-readonly.epro2`：原生只读工程导出，不是已放行制造包。
- `mic-footprint-native.json`：从实际导出工程提取的封装，含声孔记录。
- `mic-footprint.json`：早期库查询失败响应，保留作追溯；不可当作封装内容。
- `pcb-actual.svg`：根据现场快照生成的辅助正反面图；不是 Gerber 或官方制造图。
- `images/initial/snapshot.png`：EDA 原生视口截图。
- `audit-summary.json`：由原始文件派生的机器可读摘要。
- `SHA256SUMS.json`：压缩包中证据文件的 SHA-256，清单本身除外。

检查没有修改设计，也没有执行保存、重载、下单或投产操作。
