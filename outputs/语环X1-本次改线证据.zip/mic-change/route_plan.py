"""Offline candidate generation. Writes no editor data; native DRC is mandatory."""
import json, math, heapq, time
from pathlib import Path
import numpy as np
from PIL import Image, ImageDraw
from shapely.geometry import Point, Polygon, LineString, box
from shapely import affinity
from shapely.ops import unary_union
from shapely.prepared import prep

ROOT=Path(__file__).parent
B=json.load(open(ROOT/'pcb-authoritative-import.json'))
I=json.load(open(ROOT/'routing-intent.json'))
WIDTH=6.; CLEAR=5.; VIA=24.02; DRILL=12.01
STEP=5.; X0=-475.; Y0=90.; NX=587; NY=791
LAYERS=[1,2,15,16]
PADS={f"{c['designator']}.{p['padNumber']}":p for c in B['components'] for p in c['pads']}
RM=set(I['tracks']); RV=set(I['vias'])
LINES=[l for l in B['copper']['lines'] if l['primitiveId'] not in RM]
VIAS=[v for v in B['copper']['vias'] if v['primitiveId'] not in RV]
NEW=[]

def source_poly(s):
    assert s[2]=='L',s[:4]
    return Polygon([(float(s[i]),float(s[i+1])) for i in [0]+list(range(3,len(s)-1,2))]).buffer(0)
def pad_poly(p):
    s=p['shape'];typ=s[0];x=p['x'];y=p['y']
    if typ=='POLYGON':return source_poly(s[1])
    if typ in ('RECT','OVAL','ELLIPSE','ROUND','CIRCLE'):
        if typ in ('ROUND','CIRCLE'):return Point(x,y).buffer(float(s[1])/2,32)
        w,h=float(s[1]),float(s[2])
        if typ=='OVAL':
            r=min(w,h)/2
            g=LineString([(-max(0,w/2-r),-max(0,h/2-r)),(max(0,w/2-r),max(0,h/2-r))]).buffer(r,32)
        elif typ=='ELLIPSE':g=affinity.scale(Point(0,0).buffer(1,64),w/2,h/2)
        else:g=box(-w/2,-h/2,w/2,h/2)
        return affinity.translate(affinity.rotate(g,p.get('rotation',0)),x,y)
    raise ValueError(('unsupported pad',typ))

OUTLINE=Polygon(B['outline']['points']).buffer(-16)
HARD=[]
for f in B['copper']['fills']:
    if f.get('net') is None:HARD.append((12,source_poly(f['source']).buffer(f.get('lineWidth',0)/2)))
for r in B['copper']['regions']:
    if 'no-wires' in r.get('ruleTypeNames',[]):HARD.append((r['layer'],source_poly(r['source'])))

def obstacles(net):
    result={l:[] for l in LAYERS}
    for c in B['components']:
        for p in c['pads']:
            if p['net']==net:continue
            g=pad_poly(p)
            for l in LAYERS:
                if p['layer']==12 or p['layer']==l:result[l].append(g)
    for t in LINES:
        if t.get('net')==net:continue
        result[t['layer']].append(LineString([(t['startX'],t['startY']),(t['endX'],t['endY'])]).buffer(t['lineWidth']/2,8))
    for v in VIAS:
        if v.get('net')==net:continue
        g=Point(v['x'],v['y']).buffer(v.get('diameter',VIA)/2,16)
        for l in LAYERS:result[l].append(g)
    for lay,g in HARD:
        for l in LAYERS:
            if lay==12 or lay==l:result[l].append(g)
    for p in NEW:
        if p['net']==net:continue
        if p['kind']=='line':result[p['layer']].append(LineString([p['a'],p['b']]).buffer(WIDTH/2,8))
        else:
            for l in LAYERS:result[l].append(Point(*p['a']).buffer(VIA/2,16))
    return {l:unary_union(g) for l,g in result.items()}

def raster(poly):
    im=Image.new('1',(NX,NY),0);draw=ImageDraw.Draw(im)
    def coords(seq):return [((x-X0)/STEP,(y-Y0)/STEP) for x,y in seq]
    def one(p):
        draw.polygon(coords(p.exterior.coords),fill=1)
        for ring in p.interiors:draw.polygon(coords(ring.coords),fill=0)
    if poly.geom_type=='Polygon':one(poly)
    elif poly.geom_type=='MultiPolygon':
        for p in poly.geoms:one(p)
    elif not poly.is_empty:raise ValueError(poly.geom_type)
    return np.array(im,dtype=bool)

def world(x,y):return (X0+x*STEP,Y0+y*STEP)
def cell(p):return (round((p[0]-X0)/STEP),round((p[1]-Y0)/STEP))
def key(l,x,y):return (l*NY+y)*NX+x
def unkey(k):x=k%NX;k//=NX;y=k%NY;return k//NY,x,y

def solve(d):
    net=d['net'];start=PADS[d['from']];end=PADS[d['to']]
    assert start['net']==end['net']==net,(d,start['net'],end['net'])
    obs=obstacles(net)
    # Extra 1/2 grid diagonal inflation makes raster planning conservative.
    expanded=[obs[l].buffer(CLEAR+WIDTH/2+3.6) for l in LAYERS]
    blocks=[raster(g)|~raster(OUTLINE) for g in expanded]
    via_union=unary_union(list(obs.values())).buffer(CLEAR+VIA/2+3.6)
    vias=raster(via_union)|~raster(OUTLINE.buffer(-(VIA-WIDTH)/2))
    prepared={l:prep(obs[l].buffer(CLEAR+WIDTH/2-.001)) for l in LAYERS}
    def valid_segment(a,b,l):return OUTLINE.covers(LineString([a,b])) and not prepared[l].intersects(LineString([a,b]))
    # Connect exact pad centers to nearby free grid nodes on their physical layer.
    def endpoints(p):
        a=(p['x'],p['y']);cx,cy=cell(a);out=[];li=LAYERS.index(p['layer'])
        for dy in range(-6,7):
            for dx in range(-6,7):
                x=cx+dx;y=cy+dy
                if 0<=x<NX and 0<=y<NY and not blocks[li][y,x] and valid_segment(a,world(x,y),p['layer']):out.append((key(li,x,y),math.dist(a,world(x,y))/STEP))
        assert out,('no pad escape',net,a)
        return out
    starts=endpoints(start);goals=dict(endpoints(end));gx,gy=cell((end['x'],end['y']))
    def heuristic(k):l,x,y=unkey(k);return math.hypot(x-gx,y-gy)
    q=[];cost={};prev={}
    for k,c in starts:cost[k]=c;prev[k]=None;heapq.heappush(q,(c+heuristic(k),c,k))
    count=0;t=time.time();last=None
    directions=[(1,0,1),(-1,0,1),(0,1,1),(0,-1,1),(1,1,1.41421356),(1,-1,1.41421356),(-1,1,1.41421356),(-1,-1,1.41421356)]
    while q:
        f,c,k=heapq.heappop(q)
        if c!=cost.get(k):continue
        if k in goals:last=k;break
        count+=1
        if count>1500000:raise RuntimeError(('search budget',net,count))
        li,x,y=unkey(k)
        for dx,dy,dc in directions:
            xx=x+dx;yy=y+dy
            if not(0<=xx<NX and 0<=yy<NY) or blocks[li][yy,xx]:continue
            if dx and dy and (blocks[li][y,xx] or blocks[li][yy,x]):continue
            kk=key(li,xx,yy);cc=c+dc
            if cc<cost.get(kk,1e30):cost[kk]=cc;prev[kk]=k;heapq.heappush(q,(cc+heuristic(kk),cc,kk))
        if not vias[y,x]:
            for ll in range(4):
                if ll==li or blocks[ll][y,x]:continue
                kk=key(ll,x,y);cc=c+45
                if cc<cost.get(kk,1e30):cost[kk]=cc;prev[kk]=k;heapq.heappush(q,(cc+heuristic(kk),cc,kk))
    assert last is not None,('no path',net,count)
    nodes=[];k=last
    while k is not None:nodes.append(unkey(k));k=prev[k]
    nodes.reverse();path=[(LAYERS[nodes[0][0]],(start['x'],start['y']))]+[(LAYERS[l],world(x,y)) for l,x,y in nodes]+[(LAYERS[nodes[-1][0]],(end['x'],end['y']))]
    simple=[path[0]]
    for i in range(1,len(path)-1):
        la,a=simple[-1];lb,b=path[i];lc,c=path[i+1]
        if la==lb==lc and abs((b[0]-a[0])*(c[1]-b[1])-(b[1]-a[1])*(c[0]-b[0]))<1e-5:continue
        simple.append(path[i])
    simple.append(path[-1])
    # Greedy line-of-sight shortening with only orthogonal/45-degree elbows.
    smooth=[];i=0
    while i<len(simple):
        layer,a=simple[i];smooth.append((layer,a))
        if i==len(simple)-1:break
        last_same=i
        while last_same+1<len(simple) and simple[last_same+1][0]==layer:last_same+=1
        if last_same==i:i+=1;continue
        chosen=None
        for j in range(last_same,i,-1):
            b=simple[j][1];dx=b[0]-a[0];dy=b[1]-a[1]
            sx=1 if dx>=0 else -1;sy=1 if dy>=0 else -1;dd=min(abs(dx),abs(dy))
            bends=[(a[0]+sx*dd,a[1]+sy*dd),(b[0]-sx*dd,b[1]-sy*dd),(a[0],b[1]),(b[0],a[1])]
            for bend in bends:
                pts=[a]+([] if bend==a or bend==b else [bend])+[b]
                if all(valid_segment(u,v,layer) for u,v in zip(pts,pts[1:])):
                    chosen=(j,pts);break
            if chosen:break
        assert chosen
        j,pts=chosen
        for pt in pts[1:-1]:smooth.append((layer,pt))
        i=j
    simple=smooth;added=[];seen=set()
    for (la,a),(lb,b) in zip(simple,simple[1:]):
        if la!=lb:
            assert a==b
            if a not in seen:added.append({'kind':'via','net':net,'a':a});seen.add(a)
        elif a!=b:
            assert valid_segment(a,b,la),('independent segment check',net,a,b,la)
            added.append({'kind':'line','net':net,'layer':la,'a':a,'b':b})
    # Check every through via against all existing copper layers.
    for p in added:
        if p['kind']=='via':
            for l in LAYERS:assert not Point(*p['a']).buffer(VIA/2+CLEAR-.001).intersects(obs[l]),('via clearance',net,p,l)
    NEW.extend(added)
    print(net,'states',count,'seconds',round(time.time()-t,2),'segments',len(added),'vias',len(seen),flush=True)
    return dict(d,path=simple,objects=added)

if __name__=='__main__':
    demands=I['demands']
    # Route far microphones first to reserve perimeter corridors.
    order=['CK4','D4','CK3','CK2','D2','BTN2']
    paths=[solve(next(d for d in demands if d['net']==n)) for n in order]
    out={'status':'candidate-unverified','widthMil':WIDTH,'clearanceMil':CLEAR,'viaDiameterMil':VIA,'viaDrillMil':DRILL,'paths':paths,'objects':NEW,'limitations':['pours rebuild required','native DRC and save/reload required','clock edge integrity and audio alignment require sample testing']}
    (ROOT/'route-candidate.json').write_text(json.dumps(out,indent=2))
    steps=[]
    for i,p in enumerate(NEW):
        if p['kind']=='line':payload=dict(startX=p['a'][0],startY=p['a'][1],endX=p['b'][0],endY=p['b'][1],layer=p['layer'],lineWidth=WIDTH,net=p['net']);action='pcb.line.create'
        else:payload=dict(x=p['a'][0],y=p['a'][1],diameter=VIA,holeDiameter=DRILL,net=p['net']);action='pcb.via.create'
        steps.append(dict(id=f'route-{i+1}',action=action,payload=payload))
    (ROOT/'route-apply.json').write_text(json.dumps({'version':1,'meta':{'name':'Yuhuan X1 individual microphones and button','project':'MeetCard-AI-repair-loop-20261018','doc':'c513f79d0042e6d9'},'steps':steps},indent=2))
